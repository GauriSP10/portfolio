export const NAV_ITEMS = [
  { id: 'about',      label: 'About' },
  { id: 'experience', label: 'Experience' },
  { id: 'projects',   label: 'Projects' },
  { id: 'research',   label: 'Research' },
]

export const SOCIAL_LINKS = [
  {
    label: 'GitHub',
    href: 'https://github.com/GauriSP10',
    icon: `<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>`,
  },
  {
    label: 'LinkedIn',
    href: 'https://linkedin.com/in/gauri-prabhakar',
    icon: `<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>`,
  },
  {
    label: 'Instagram',
    href: 'https://instagram.com',
    icon: `<rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>`,
  },
  {
    label: 'Twitter',
    href: 'https://twitter.com',
    icon: `<path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.7 5.5 4.3 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>`,
  },
]

export const EMAIL = 'gprabhakar1820@gmail.com'

export const EXPERIENCE = [
  {
    date: 'Oct 2024 — Jun 2025',
    title: 'Machine Learning Engineer',
    company: 'AYU',
    href: '#',
    desc: 'Led design of Conversational AI for mood tracking and wellness using LLMs and custom NLP pipelines. Integrated Generative AI APIs for context-aware responses and built modular FastAPI + MongoDB backend for scalable async chatbot interactions. Developed sentiment analysis and personalization strategies.',
    tags: [
      { label: 'PyTorch',  color: 'teal' },
      { label: 'LLMs',     color: 'teal' },
      { label: 'FastAPI',  color: 'blue' },
      { label: 'MongoDB',  color: 'blue' },
      { label: 'NLP',      color: 'amber' },
    ],
  },
  {
    date: 'Sep 2022 — Sep 2024',
    title: 'Software Engineer',
    company: 'SLB (Schlumberger)',
    href: '#',
    desc: 'Developed .NET API endpoints achieving 80% improvement in response time. Migrated 327,000+ hierarchical MongoDB records and built 10+ APIGEE proxies with shared flow policy for 50+ proxies. Prototyped a Python + Streamlit chatbot using documents, wiki pages, and transcripts as corpus.',
    tags: [
      { label: '.NET',      color: 'blue' },
      { label: 'MongoDB',   color: 'blue' },
      { label: 'APIGEE',    color: 'amber' },
      { label: 'Streamlit', color: 'teal' },
    ],
  },
  {
    date: 'Feb 2022 — Aug 2022',
    title: 'Machine Learning Engineer',
    company: 'iSchoolConnect',
    href: '#',
    desc: 'Built in-house Streamlit UI for recommendation system, reducing cross-team dependency by 85%. Improved accuracy via feature manipulation and deployed pipeline detecting database discrepancies with automated email alerts. Restructured 20,000+ data points and scraped/cleaned 2,000+ via Python pipelines.',
    tags: [
      { label: 'Recommendation Systems', color: 'teal' },
      { label: 'Streamlit',              color: 'blue' },
      { label: 'Python Pipelines',       color: 'amber' },
    ],
  },
]

export const PROJECTS = [
  {
    title: 'GPU Scheduler with Multi-Agent RL',
    desc: 'GPUs negotiate workload allocation using multi-agent reinforcement learning (MAPPO). Benchmarked against Kubernetes baseline across simulated cluster environments.',
    date: 'Dec 2025 — Present',
    href: '#',
    github: 'https://github.com/GauriSP10',
    tags: [
      { label: 'Ray RLlib',   color: 'teal' },
      { label: 'MAPPO',       color: 'teal' },
      { label: 'Kubernetes',  color: 'blue' },
    ],
    featured: false,
  },
  {
    title: 'Cryptographic Model Fingerprinting',
    desc: 'Embeds cryptographic signatures in neural network weights to identify AI-generated content origins — robust to compression, adversarial attacks, and fine-tuning.',
    date: 'Aug — Sep 2025',
    href: '#',
    github: 'https://github.com/GauriSP10',
    tags: [
      { label: 'Stable Diffusion XL', color: 'teal' },
      { label: 'Llama 2/3',           color: 'teal' },
      { label: 'CleverHans',          color: 'amber' },
    ],
    featured: false,
  },
  {
    title: 'Algorithm Visualizer',
    desc: 'Data structures visualization tool with GUI enabling executable download without dependencies. Research published in IEEE.',
    date: 'Nov 2021 — Jan 2022',
    href: '#',
    github: 'https://github.com/GauriSP10',
    tags: [
      { label: 'Python',          color: 'blue' },
      { label: 'tkinter',         color: 'blue' },
      { label: 'IEEE Publication', color: 'amber' },
    ],
    featured: false,
  },
  {
    title: 'Streamlit Login / Sign-Up UI',
    desc: 'Open-source PyPI library providing a functional login page with email and cookie support for Streamlit apps. Received special acknowledgement from the Streamlit team.',
    date: 'Aug 2022 — Present',
    href: 'https://pypi.org/project/streamlit-login-auth-ui/',
    github: 'https://github.com/GauriSP10',
    badge: '30k+ downloads',
    tags: [
      { label: 'PyPI',        color: 'teal' },
      { label: 'Streamlit',   color: 'blue' },
      { label: 'Open Source', color: 'amber' },
    ],
    featured: true,
  },
]

export const RESEARCH = [
  {
    venue: 'IEEE',
    year: '2022',
    title: 'Algorithm Visualizer: An Interactive Data Structures Education Tool',
    desc: 'Standalone GUI application for visualizing sorting and data structure algorithms with executable distribution requiring no dependency installation.',
    href: '#',
  },
  {
    venue: 'PyPI Library',
    year: '2022 — Now',
    title: 'streamlit-login-auth-ui',
    desc: '30,000+ downloads. Functional auth UI with email verification and cookie-based session support for Streamlit apps. Acknowledged by the Streamlit team.',
    href: 'https://pypi.org/project/streamlit-login-auth-ui/',
  },
]

export const SKILLS = {
  Languages: ['Python', 'C++', 'Rust', 'C#', 'Java'],
  'AI / ML':  ['PyTorch', 'TensorFlow', 'Hugging Face', 'Ray RLlib', 'LLMs · NLP'],
  Infra:      ['FastAPI · Flask', 'Docker · K8s', 'MongoDB · Redis', 'Azure · CI/CD', 'Pinecone'],
}
