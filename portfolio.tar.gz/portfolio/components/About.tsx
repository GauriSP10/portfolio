'use client'
import { SKILLS } from '@/lib/data'

export default function About() {
  return (
    <section id="about" className="mb-24 scroll-mt-20">
      <SectionLabel index="01" label="About" />

      <div className="space-y-5">
        <p className="text-[15px] leading-[1.8]" style={{ color: 'var(--text-secondary)' }}>
          I'm a Machine Learning Engineer currently pursuing my{' '}
          <span className="font-medium" style={{ color: 'var(--accent-teal)' }}>Master's in AI</span>{' '}
          at Northeastern University, Boston. I build systems that sit at the intersection of
          language models, reinforcement learning, and scalable backend infrastructure.
        </p>
        <p className="text-[15px] leading-[1.8]" style={{ color: 'var(--text-secondary)' }}>
          My work spans from{' '}
          <span className="font-medium" style={{ color: 'var(--accent-blue)' }}>conversational AI and NLP pipelines</span>{' '}
          to multi-agent RL systems for GPU scheduling. I care about models that are not just
          accurate — but robust, interpretable, and production-ready.
        </p>
        <p className="text-[15px] leading-[1.8]" style={{ color: 'var(--text-secondary)' }}>
          Outside the lab, I've published on{' '}
          <span className="font-medium" style={{ color: 'var(--accent-teal)' }}>PyPI</span>{' '}
          with 30,000+ downloads, contributed to IEEE research, and worked with NGOs across
          India through Rotaract.
        </p>

        {/* Skills grid */}
        <div
          className="grid grid-cols-3 gap-4 mt-8 p-6 rounded-xl border"
          style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          {Object.entries(SKILLS).map(([category, items]) => (
            <div key={category}>
              <p
                className="font-mono text-[10px] tracking-[0.12em] uppercase mb-3"
                style={{ color: 'var(--accent-teal)' }}
              >
                {category}
              </p>
              <ul className="space-y-1.5">
                {items.map(item => (
                  <li
                    key={item}
                    className="font-mono text-[12px] pl-3 relative"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <span
                      className="absolute left-0 text-[10px]"
                      style={{ color: 'var(--accent-teal)' }}
                    >▸</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function SectionLabel({ index, label }: { index: string; label: string }) {
  return (
    <div className="flex items-center gap-3 mb-8">
      <span className="font-mono text-[11px] tracking-[0.14em] uppercase" style={{ color: 'var(--accent-teal)' }}>
        {index}
      </span>
      <span className="font-mono text-[11px] tracking-[0.14em] uppercase" style={{ color: 'var(--text-muted)' }}>
        {label}
      </span>
      <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
    </div>
  )
}
