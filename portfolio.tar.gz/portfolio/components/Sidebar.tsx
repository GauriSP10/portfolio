'use client'
import { useEffect, useState } from 'react'
import { NAV_ITEMS } from '@/lib/data'

export default function Sidebar() {
  const [active, setActive] = useState('about')

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(e => {
          if (e.isIntersecting) setActive(e.target.id)
        })
      },
      { rootMargin: '-40% 0px -50% 0px', threshold: 0 }
    )
    NAV_ITEMS.forEach(({ id }) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <aside className="lg:sticky lg:top-0 lg:h-screen flex flex-col justify-between py-20 lg:w-[340px] shrink-0">
      {/* Top */}
      <div>
        {/* Name & role */}
        <div className="mb-10" style={{ animationDelay: '0.1s' }}>
          <h1
            className="text-[32px] font-semibold tracking-tight leading-none mb-2"
            style={{ color: 'var(--text-primary)' }}
          >
            Gauri Prabhakar
          </h1>
          <h2
            className="font-mono text-[13px] tracking-widest uppercase mb-4"
            style={{ color: 'var(--accent-teal)' }}
          >
            ML Engineer
          </h2>
          <p
            className="text-sm leading-relaxed max-w-[240px]"
            style={{ color: 'var(--text-secondary)' }}
          >
            Building intelligent systems<br />
            at the edge of language + learning.
          </p>
        </div>

        {/* Nav */}
        <nav aria-label="Sections" className="flex flex-col gap-1">
          {NAV_ITEMS.map(({ id, label }) => {
            const isActive = active === id
            return (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                className="flex items-center gap-4 py-1.5 text-left group cursor-pointer bg-transparent border-none outline-none"
              >
                <span
                  className="h-px flex-shrink-0 transition-all duration-300"
                  style={{
                    width: isActive ? '48px' : '24px',
                    background: isActive ? 'var(--nav-line-active)' : 'var(--text-muted)',
                  }}
                />
                <span
                  className="font-mono text-[11px] tracking-[0.12em] uppercase transition-colors duration-300"
                  style={{ color: isActive ? 'var(--text-primary)' : 'var(--text-muted)' }}
                >
                  {label}
                </span>
              </button>
            )
          })}
        </nav>
      </div>

      {/* Bottom — resume link */}
      <div>
        <a
          href="/resume.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 font-mono text-[11px] tracking-widest uppercase
            px-4 py-2 rounded border transition-all duration-200"
          style={{
            color: 'var(--text-secondary)',
            borderColor: 'var(--border)',
            background: 'transparent',
          }}
          onMouseEnter={e => {
            const el = e.currentTarget
            el.style.color = 'var(--accent-teal)'
            el.style.borderColor = 'var(--accent-teal)'
            el.style.background = 'var(--tag-teal-bg)'
          }}
          onMouseLeave={e => {
            const el = e.currentTarget
            el.style.color = 'var(--text-secondary)'
            el.style.borderColor = 'var(--border)'
            el.style.background = 'transparent'
          }}
        >
          View Full Résumé
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
          </svg>
        </a>
      </div>
    </aside>
  )
}
