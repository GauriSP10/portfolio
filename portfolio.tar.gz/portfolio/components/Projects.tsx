'use client'
import { useState } from 'react'
import { PROJECTS } from '@/lib/data'
import { SectionLabel } from './About'
import Tag from './Tag'

export default function Projects() {
  return (
    <section id="projects" className="mb-24 scroll-mt-20">
      <SectionLabel index="03" label="Projects" />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {PROJECTS.map(p => (
          p.featured
            ? <FeaturedCard key={p.title} {...p} />
            : <ProjectCard key={p.title} {...p} />
        ))}
      </div>
    </section>
  )
}

function ProjectCard({ title, desc, date, href, github, badge, tags }: typeof PROJECTS[0]) {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="flex flex-col gap-2.5 p-5 rounded-xl border transition-all duration-250 cursor-default relative overflow-hidden"
      style={{
        background: 'var(--bg-card)',
        borderColor: hovered ? 'var(--border-hover)' : 'var(--border)',
        transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
        boxShadow: hovered ? '0 12px 40px rgba(100,255,204,0.05)' : 'none',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* subtle gradient overlay on hover */}
      <div
        className="absolute inset-0 rounded-xl pointer-events-none transition-opacity duration-300"
        style={{
          background: 'linear-gradient(135deg, rgba(100,255,204,0.03) 0%, transparent 60%)',
          opacity: hovered ? 1 : 0,
        }}
      />

      <div className="flex items-start justify-between">
        <svg style={{ color: 'var(--accent-teal)', opacity: 0.7 }} width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
        </svg>
        <div className="flex items-center gap-2">
          {badge && (
            <span className="font-mono text-[10px] px-2 py-0.5 rounded-full tag-amber">{badge}</span>
          )}
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="View project"
            className="transition-all duration-200"
            style={{
              color: 'var(--text-muted)',
              opacity: hovered ? 1 : 0,
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/>
            </svg>
          </a>
        </div>
      </div>

      <h3 className="text-[14px] font-medium leading-snug" style={{ color: 'var(--text-primary)' }}>
        {title}
      </h3>

      <p className="text-[13px] leading-[1.7] flex-1" style={{ color: 'var(--text-secondary)' }}>
        {desc}
      </p>

      <div className="flex flex-wrap gap-1.5 mt-auto">
        {tags.map(t => <Tag key={t.label} label={t.label} color={t.color as 'teal' | 'blue' | 'amber'} />)}
      </div>

      <p className="font-mono text-[10px]" style={{ color: 'var(--text-muted)' }}>{date}</p>
    </div>
  )
}

function FeaturedCard({ title, desc, date, href, github, badge, tags }: typeof PROJECTS[0]) {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="sm:col-span-2 flex flex-col sm:flex-row gap-5 p-5 rounded-xl border transition-all duration-250 cursor-default relative overflow-hidden"
      style={{
        background: 'var(--bg-card)',
        borderColor: hovered ? 'var(--border-hover)' : 'var(--border)',
        transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
        boxShadow: hovered ? '0 12px 40px rgba(100,255,204,0.05)' : 'none',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        className="absolute inset-0 rounded-xl pointer-events-none transition-opacity duration-300"
        style={{
          background: 'linear-gradient(135deg, rgba(100,255,204,0.03) 0%, transparent 60%)',
          opacity: hovered ? 1 : 0,
        }}
      />

      {/* Icon col */}
      <div className="flex-shrink-0 flex sm:flex-col justify-between sm:justify-start gap-4 sm:gap-3">
        <svg style={{ color: 'var(--accent-teal)', opacity: 0.7 }} width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
        </svg>
        {badge && (
          <span className="font-mono text-[10px] px-2 py-0.5 rounded-full tag-amber whitespace-nowrap">{badge}</span>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-2.5 flex-1">
        <div className="flex items-start justify-between">
          <h3 className="text-[14px] font-medium leading-snug" style={{ color: 'var(--text-primary)' }}>
            {title}
          </h3>
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="transition-all duration-200 ml-2 flex-shrink-0"
            style={{ color: 'var(--text-muted)', opacity: hovered ? 1 : 0 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/>
            </svg>
          </a>
        </div>

        <p className="text-[13px] leading-[1.7]" style={{ color: 'var(--text-secondary)' }}>
          {desc}
        </p>

        <div className="flex flex-wrap gap-1.5">
          {tags.map(t => <Tag key={t.label} label={t.label} color={t.color as 'teal' | 'blue' | 'amber'} />)}
        </div>

        <p className="font-mono text-[10px]" style={{ color: 'var(--text-muted)' }}>{date}</p>
      </div>
    </div>
  )
}
