'use client'

export default function Footer() {
  return (
    <footer className="pt-10 pb-16 border-t" style={{ borderColor: 'var(--border)' }}>
      <p className="text-[13px] leading-relaxed" style={{ color: 'var(--text-muted)' }}>
        Designed &amp; built by{' '}
        <span style={{ color: 'var(--accent-teal)' }}>Gauri Prabhakar</span>.
        Inspired by{' '}
        <a
          href="https://brittanychiang.com"
          target="_blank"
          rel="noopener noreferrer"
          className="transition-colors duration-200 underline underline-offset-2"
          style={{ color: 'var(--text-muted)' }}
          onMouseEnter={e => (e.currentTarget.style.color = 'var(--accent-teal)')}
          onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
        >
          Brittany Chiang
        </a>.
      </p>
      <p className="font-mono text-[11px] mt-1" style={{ color: 'var(--text-muted)' }}>
        Built with Next.js &amp; Tailwind CSS · Deployed on Vercel
      </p>
    </footer>
  )
}
