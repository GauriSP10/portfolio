'use client'
import { useState } from 'react'
import { RESEARCH } from '@/lib/data'
import { SectionLabel } from './About'

export default function Research() {
  return (
    <section id="research" className="mb-24 scroll-mt-20">
      <SectionLabel index="04" label="Research & Writing" />
      <div className="flex flex-col gap-1">
        {RESEARCH.map(r => <ResearchCard key={r.title} {...r} />)}
      </div>
    </section>
  )
}

function ResearchCard({ venue, year, title, desc, href }: typeof RESEARCH[0]) {
  const [hovered, setHovered] = useState(false)

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="grid gap-x-5 p-5 rounded-xl border no-underline transition-all duration-250"
      style={{
        gridTemplateColumns: '120px 1fr 20px',
        background: hovered ? 'var(--bg-card-hover)' : 'transparent',
        borderColor: hovered ? 'var(--border-hover)' : 'transparent',
        transform: hovered ? 'translateY(-2px)' : 'translateY(0)',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Meta */}
      <div className="flex flex-col gap-1 pt-0.5">
        <span className="font-mono text-[10px] tracking-widest uppercase" style={{ color: 'var(--accent-teal)' }}>
          {venue}
        </span>
        <span className="font-mono text-[10px]" style={{ color: 'var(--text-muted)' }}>
          {year}
        </span>
      </div>

      {/* Content */}
      <div>
        <h3 className="text-[15px] font-medium leading-snug mb-2" style={{ color: 'var(--text-primary)' }}>
          {title}
        </h3>
        <p className="text-[13px] leading-[1.7]" style={{ color: 'var(--text-secondary)' }}>
          {desc}
        </p>
      </div>

      {/* Arrow */}
      <div
        className="pt-1 transition-all duration-200"
        style={{
          color: 'var(--accent-teal)',
          opacity: hovered ? 1 : 0,
          transform: hovered ? 'translate(2px, -2px)' : 'translate(0,0)',
        }}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/>
        </svg>
      </div>
    </a>
  )
}
