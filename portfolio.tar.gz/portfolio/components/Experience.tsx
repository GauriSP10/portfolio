'use client'
import { useState } from 'react'
import { EXPERIENCE } from '@/lib/data'
import { SectionLabel } from './About'
import Tag from './Tag'

export default function Experience() {
  return (
    <section id="experience" className="mb-24 scroll-mt-20">
      <SectionLabel index="02" label="Experience" />

      <div className="flex flex-col gap-1">
        {EXPERIENCE.map((job) => (
          <ExperienceCard key={job.company} {...job} />
        ))}
      </div>

      <a
        href="/resume.pdf"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 mt-6 ml-5 font-mono text-[12px] transition-all duration-200"
        style={{ color: 'var(--accent-teal)' }}
        onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.gap = '10px' }}
        onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.gap = '8px' }}
      >
        View Full Résumé
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
        </svg>
      </a>
    </section>
  )
}

function ExperienceCard({ date, title, company, href, desc, tags }: typeof EXPERIENCE[0]) {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="grid gap-6 p-5 rounded-xl border transition-all duration-250 cursor-default"
      style={{
        gridTemplateColumns: '120px 1fr',
        background: hovered ? 'var(--bg-card-hover)' : 'transparent',
        borderColor: hovered ? 'var(--border-hover)' : 'transparent',
        transform: hovered ? 'translateY(-2px)' : 'translateY(0)',
        boxShadow: hovered ? '0 8px 32px rgba(100,255,204,0.04)' : 'none',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Date */}
      <div
        className="font-mono text-[11px] text-right pt-0.5 leading-relaxed whitespace-nowrap"
        style={{ color: 'var(--text-muted)' }}
      >
        {date}
      </div>

      {/* Body */}
      <div>
        <div className="flex items-center gap-1.5 flex-wrap mb-2">
          <h3 className="text-[15px] font-medium" style={{ color: 'var(--text-primary)' }}>
            {title}
          </h3>
          <span className="text-[14px]" style={{ color: 'var(--accent-teal)' }}>
            · {company}
          </span>
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="transition-all duration-200 ml-1"
            style={{
              color: 'var(--text-muted)',
              opacity: hovered ? 1 : 0,
            }}
            aria-label={`${company} website`}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
            </svg>
          </a>
        </div>

        <p className="text-[14px] leading-[1.7] mb-3" style={{ color: 'var(--text-secondary)' }}>
          {desc}
        </p>

        <div className="flex flex-wrap gap-1.5">
          {tags.map(t => <Tag key={t.label} label={t.label} color={t.color as 'teal' | 'blue' | 'amber'} />)}
        </div>
      </div>
    </div>
  )
}
